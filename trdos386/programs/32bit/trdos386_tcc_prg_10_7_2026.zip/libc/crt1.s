.global main
.text

/* Kod do�rudan 0. bayttan ba�lar, kayma riski s�f�rd�r! */
_start_entry:
    popl %eax                       /* argc de�erini %eax'e �ek */
    movl %esp, %ebx                 /* %esp (argv pointer) -> %ebx */
    pushl %ebx                      /* �kinci parametre: argv */
    pushl %eax                      /* Birinci parametre: argc */
    
    call main                       /* TCC 'main' sembol�n� ba�layacak */
    
    addl $8, %esp                   /* Stack temizli�i */
    
    movl %eax, %ebx                 /* main()'den d�nen exit code -> %ebx */
    movl $1, %eax                   /* %eax = 1 (sys_exit) */
    int $0x40                       /* TRDOS Kernel Resmi Kesmesi */
