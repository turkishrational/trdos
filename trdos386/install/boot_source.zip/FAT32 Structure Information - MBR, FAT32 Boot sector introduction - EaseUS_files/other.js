$(function(){
	var float_js={
		year:function(){
		$("#year").html('Copyright © 2004 - 2017 EaseUS. ALL RIGHTS RESERVED.');
		},
		all_pop:function(id,links,title){
			if($(id).length>0){
				var left=$(window).width()/2-290;
				var top=$(window).height()/2-290;//获取高宽
				var openvalue='height=580,width=580,top='+top+',left='+left+',toolbar=no,menubar=no,scrollbars=no, resizable=no,location=no, status=no';//设置弹出属性
				$(document).on('click',id,function(){
					window.open(links,title,openvalue);
				});
			}
		},
		mail_pop_show:function(){
			function download_pop_show(){
				if($('.download_pop_show').length>0){
					var dom=document.createElement('script');
					dom.src='/default/js/download_pop_show.js';
					document.body.appendChild(dom);
				}
			}
			download_pop_show();
			var upgrade_pop_show=function(){
				if($('.upgrade_pop_show').length>0){
					var dom=document.createElement('script');
					dom.src='/default/js/upgrade_mail_pop.js';
					document.body.appendChild(dom);
				}
			};
			upgrade_pop_show();
			var check_pop=function(){
				if($('.check_pop_button').length>0){
					var dom=document.createElement('script');
					dom.src='/default/js/check_pop.js';
					document.body.appendChild(dom);
				}
			};
			check_pop();
		},
		to_top:function(){//and livechat
			var totop_html='<div class="float_totop hidden"></div>';
			$('body').append(totop_html);
			$(window).scroll(function(){//totop滚动
				if($(window).scrollTop()>450){
					$('.float_totop').removeClass('hidden');
				}else{
					$('.float_totop').addClass('hidden');
				}
			});
			$('.float_totop').click(function(){
				$('body,html').animate({scrollTop:0},600);
			});
		},
		all_float:function(){
			var self=this;
			function window_mouse_bind(clas,currents,mouse){//bind window mouse
				function fun(){
					currents.removeClass('current');
					$(document).unbind('click',fun);
				}
				clas.click(function(){
					if(currents.hasClass('current')){
						currents.removeClass('current');
					}else{
						currents.addClass('current');
					}
				});
				mouse.unbind('mouseleave').unbind('mouseenter');
				mouse.mouseleave(function(){
					$(document).bind('click',fun);
				}).mouseenter(function(){
					$(document).unbind('click',fun);
				});
			}
			//livechat->html
			var livechat_outside_html='<div class="float_livechat"><div class="show">LiveChat</div></div>';
			var livechat_inside_html='<div class="livechat_content"><div class="bg">LiveChat<span class="close">&nbsp;</span></div><p class="title">Need help? We\'re here for you.</p><dl class="tech"><dt>Technical Support</dt><dd class="dis">For paid users only. Professional support on all technique problems.</dd></dl><dl class="click"><dt>Pre-Sales Inquiry</dt><dd class="dis">Inquiry,quote,sales order,license code, invoice and download link,etc.</dd></dl></div>';
			$('body').append(livechat_outside_html);
			$('.float_livechat,.toplink li.livechat').append(livechat_inside_html);
			self.all_pop('.livechat_content .click,.livechat_window_pop','https://secure.livechatinc.com/licence/1389892/open_chat.cgi?groups=3','livechat');
			$('.livechat_content .tech').click(function(){window.open('https://secure.livechatinc.com/licence/1389892/open_chat.cgi?groups=2');});
			//float_livechat run
			window_mouse_bind($('.livechat .livechat_hover'),$('.livechat .livechat_hover').parent(),$('.livechat .livechat_hover').parent());//bind window mouse run
			window_mouse_bind($('.float_livechat .show'),$('.float_livechat .show').parent(),$('.float_livechat .show').parent());
			$(document).on('click','.livechat_content .close',function(){$(this).parent().parent().parent().removeClass('current');});
			//all share
			var share_pop=function(){
				var url=document.URL;
				var title=$('title').eq(0).html();
				var twitter_title='';//twitter用的title
				var text_len=120-url.length;
				if(title.length>text_len){
					twitter_title=title.substr(0,text_len)+'...';
				}else{
					twitter_title=title;
				}
				self.all_pop('.share_facebook','http://www.facebook.com/sharer/sharer.php?u='+url,'facebook');
				self.all_pop('.share_twitter','https://twitter.com/intent/tweet?text='+twitter_title+'&url='+url+'&via=EaseUS','twitter');
				self.all_pop('.share_google','https://plus.google.com/share?url='+url,'google');
			};
			share_pop();
			//多语言弹出的那玩意
			var language_html='<div class="language_top"><div class="wrap clearfix"><span class="close"></span><p class="title">CHOOSE YOUR REGION</p><div class="list_box"><dl class="list"><dt>North America</dt><dd><a class="current" href="https://www.easeus.com">United States<span>(English)</span></a><a href="https://www.easeus.com">Canada<span>(English)</span></a><a class="canada_fr" href="https://www.easeus.fr">Canada<span>(Francais)</span></a></dd></dl><dl class="list"><dt>Latin America </dt><dd><a href="https://br.easeus.com">Brasil<span>(Português)</span></a><a href="https://es.easeus.com">México<span>(Español)</span></a><a href="https://es.easeus.com">Chile<span>(Español)</span></a><a href="https://es.easeus.com">Argentina<span>(Español)</span></a></dd></dl></div><div class="list_box"><dl class="list"><dt>Europe</dt><dd><a class="deutschland_de" href="https://www.easeus.de/">Deutschland<span>(Deutsch)</span></a><a class="deutschland_de" href="https://www.easeus.de/">Österreich<span>(Deutsch)</span></a><a class="france_fr" href="https://www.easeus.fr">France<span>(Francais)</span></a><a class="belgique_fr" href="https://www.easeus.fr">Belgique<span>(Francais)</span></a><a href="https://nl.easeus.com/">België<span>(Nederlands)</span></a><a href="https://es.easeus.com">España<span>(Español)</span></a><a href="https://it.easeus.com">Italia<span>(Italiano)</span></a><a href="https://br.easeus.com">Portugal<span>(Português)</span></a><a href="https://uk.easeus.com">United Kingdom<span>(English)</span></a><a href="https://nl.easeus.com">Nederland<span>(Nederlands)</span></a><a href="http://www.easeus.net.pl">Polska<span>(Polski)</span></a><a href="http://www.easeus.cz">Česká<span>(Čeština)</span></a></dd></dl></div><div class="list_box last"><dl class="list"><dt>Asia Pacific</dt><dd><a href="https://www.easeus.com">Australia<span>(English)</span></a><a href="https://www.easeus.com">Singapore<span>(English)</span></a><a href="https://www.easeus.com">New Zealand<span>(English)</span></a><a class="japan" href="https://jp.easeus.com/">日本<span>（日本語）</span></a><a href="http://www.easeus.co.kr">대한민국<span>(한국어)</span></a><a href="http://cn.easeus.com/">中国<span>(简体中文)</span></a><a href="https://tw.easeus.com/">台灣<span>(繁體中文)</span></a><a href="https://tw.easeus.com/">香港<span>(繁體中文)</span></a><a href="/">Hong Kong<span>(English)</span></a><a href="https://www.easeus.com">India<span>(English)</span></a><a href="http://www.easeus.co.id">Indonesia<span>(Bahasa Indonesia)</span></a><a href="http://www.easeus.ae">امارات عربية متحدة&lrm;<span>(العربية)</span></a></dd></dl><dl class="list"><dt>International</dt><dd><a href="https://www.easeus.com">English</a></dd></dl></div></div></div>';
			$('body').append(language_html);
			window_mouse_bind($('.toplink .united_span,.language_bottom_click'),$('.language_top'),$('.toplink .united_span,.language_bottom_click,.language_top'));
			$('.language_top .close').click(function(){
				$('.language_top').removeClass('current');
			});
			//语言切换
			var dom=document.createElement('script');
			dom.src='/default/js/language.js';
			document.body.appendChild(dom);
			//新增的弹出窗口
			self.all_pop('#Context .bt_livechat .this_bt','https://secure.livechatinc.com/licence/1389892/open_chat.cgi?groups=2','livechat');
		},
		input_word_show:function(){
			$('.word_hide_show').each(function(){
				var word_hide_show=$(this);
				var word=word_hide_show.val();
				word_hide_show.focus(function(){
					var this_word=$(this).val();
					if(word==this_word){
						word_hide_show.val('');
					}
				}).blur(function(){
					var this_word=$(this).val();
					if(this_word==''){
						word_hide_show.val(word);
					}
				});
			});
		},
		article:function(){
			var float_bottom=function(){
				if($('.float_bottom').length>0){
					var gura_f_top=$('.footer').offset().top;
					var scs=function(){
						var top=$(window).scrollTop()+$(window).height();
						if(top>=gura_f_top){
							$(".float_bottom").removeClass('current');
						}else{
							$(".float_bottom").addClass('current');
						}
					};
					$(window).bind('scroll',scs);
					$('.float_bottom .colse').click(function(){
						$(this).parent().parent().removeClass('current');
						$(window).unbind('scroll',scs);
					});
				}
			};
			//float_bottom();
			//button->change->linkid
			var article_linkid=function(){
				var buy_linkid=document.URL;
				buy_linkid=buy_linkid.replace(/http\:\/\/.*?\/|\?.*|\.html{0,1}/g,'');
				buy_linkid=buy_linkid.replace(/\//g,'---');
				//set buy_linkid
				$('.article_content .article_button.buy').each(function(){
					var url=$(this).attr('href');
					var linkids=url.match(/linkid\=.*/);
					if(linkids!=null){
						linkids=linkids[0];
						if(/\&/.test(linkids)){
							linkids=linkids.split('&');
							linkids=linkids[0];
						}
						url=url.replace(linkids,linkids+'_'+buy_linkid);
						$(this).attr({href:url});
					}else{
						if(!(/javascript\:void\(0\)/.test(url))){
							$(this).attr({href:url+'&linkid=_'+buy_linkid});
						}
					}
				});
			};
			article_linkid();
		}
	};
	float_js.to_top();
	float_js.all_float();
	float_js.article();
	float_js.mail_pop_show();
	float_js.input_word_show();
	float_js.year();
});
//暂时增加ab测试，pc trans暂用
var pctrans_ab_test=function(){};
$(function(){
	pctrans_ab_test=function(data){
		if(data==0){
			cookie.setcookie('pctrans_ab_test','no1');
		}else if(data==1){
			cookie.setcookie('pctrans_ab_test','no2');
		}
		//.store_backup_test,.tb_home_test,.epm_server_test,.epm_unlimited_test,.disk_copy_test,.pctrans_ab_test
		$('.epm_tech_test').each(function(){
			var this_classname=$(this).get(0).className;
			var link_next=this.href;
			if((/\?/.test(link_next))){
				link_next='?'+link_next.replace(/^.*\?/,'');
			}else{
				link_next='';
			}
			if(data==0){
				cookie.setcookie('pctrans_ab_test','no1');
				if(/pctrans\_ab\_test/g.test(this_classname)){
					$(this).attr({href:'/pc-transfer-software/pctrans-pro-buy.html'+link_next});
				}else if(/disk\_copy\_test/g.test(this_classname)){
					$(this).attr({href:'/disk-copy/technician-edition/buy.html'+link_next});
				}else if(/epm\_tech\_test/g.test(this_classname)){
					$(this).attr({href:'/partition-manager/epm-technician-buy.html'+link_next});
				}else if(/epm\_pro\_test/g.test(this_classname)){
					$(this).attr({href:'/partition-manager/epm-pro-buy.html'+link_next});
				}else if(/epm\_server\_test/g.test(this_classname)){
					$(this).attr({href:'/partition-manager/epm-server-buy.html'+link_next});
				}else if(/epm\_unlimited\_test/g.test(this_classname)){
					$(this).attr({href:'/partition-manager/epm-unlimited-buy.html'+link_next});
				}else if(/tb\_home\_test/g.test(this_classname)){
					$(this).attr({href:'/backup-software/tb-home-buy.html'+link_next});
				}else if(/store\_backup\_test/g.test(this_classname)){
					$(this).attr({href:'/store/backup-buy.html'+link_next});
				}
			}else if(data==1){
				cookie.setcookie('pctrans_ab_test','no2');
				if(/pctrans\_ab\_test/g.test(this_classname)){
					$(this).attr({href:'/pc-transfer-software/pctrans-pro-purchase.html'+link_next});
				}else if(/disk\_copy\_test/g.test(this_classname)){
					$(this).attr({href:'/disk-copy/technician-edition/purchase.html'+link_next});
				}else if(/epm\_tech\_test/g.test(this_classname)){
					$(this).attr({href:'/partition-manager/epm-technician-purchase.html'+link_next});
				}else if(/epm\_pro\_test/g.test(this_classname)){
					$(this).attr({href:' /partition-manager/epm-pro-purchase.html'+link_next});
				}else if(/epm\_server\_test/g.test(this_classname)){
					$(this).attr({href:'/partition-manager/epm-server-purchase.html'+link_next});
				}else if(/epm\_unlimited\_test/g.test(this_classname)){
					$(this).attr({href:'/partition-manager/epm-unlimited-purchase.html'+link_next});
				}else if(/tb\_home\_test/g.test(this_classname)){
					$(this).attr({href:'/backup-software/tb-home-store.html'+link_next});
				}else if(/store\_backup\_test/g.test(this_classname)){
					$(this).attr({href:'/store/backup.html'+link_next});
				}
			}
		})
	};
	//var pctrans_ab_test_data=cookie.getcookie('pctrans_ab_test');
//	if(pctrans_ab_test_data=='no1'){
//		pctrans_ab_test(0);
//	}else if(pctrans_ab_test_data=='no2'){
//		pctrans_ab_test(1);
//	}else{
//		var dom=document.createElement('script');
//		dom.src='https://www.easeus.com/getflag.php?callback=pctrans_ab_test';
//		document.body.appendChild(dom);
//	}
});