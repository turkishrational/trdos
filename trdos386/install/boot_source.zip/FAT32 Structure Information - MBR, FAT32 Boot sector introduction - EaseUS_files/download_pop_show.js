var download_fun=function(){};
$(function(){
	var download_mail=function(){
		var submit_s='no';
		var check_mail=function(s,error){
			s=s.replace(/\s*/,'');
			var pattern =/^[a-zA-Z0-9_\-.]{1,}@[a-zA-Z0-9_\-]{1,}\.[a-zA-Z0-9_\-.]{1,}$/;
			if(s!=""){
				 if(s.length<11){
					error.removeClass('hidden').html('Please enter a valid e-mail');
					submit_s='no';
				 }else{
					 if(!pattern.exec(s)){
						error.removeClass('hidden').html('Please enter a valid e-mail');
						submit_s='no';
					 }else{
						error.addClass('hidden');
						submit_s='yes';
					 }
				 }
			}else{
				error.removeClass('hidden').html('E-mail can\'t be empty');
				$('#download_email').val('');
				submit_s='no';
			}
		}
		var download_check=function(){
			this.email=function(){
				var download_html='<div class="download_pop hidden"><div class="bg"></div><div class="content"><span class="close"></span><p class="title">Download EaseUS Todo Backup Advanced Server</p><div class="clearfix"><div class="left no1"><p class="t_title" id="download_poptitle">Fill out the form below for a <font>30-day free trial</font>.</p><p class="dis">Be the first one to get exclusive special offer from EaseUS.</p><p class="email_title">Email:</p><div class="input"><input type="text" id="download_email" name="email" value="Your Email Address" class="text word_hide_show" /><input type="hidden" name="ptype" id="ptype" value="tbfree"><input type="hidden" name="web" id="web" value="easeus"></div><p class="error hidden"></p><p class="check">* Your information will only be used by EaseUS and only for subjects related to EaseUS\' products and services..</p><input type="button" class="submit" value="Submit" /></div><div class="left no2 hidden"><p class="t_title2">Start your free trial</p><p class="dis2">Click the download link below to start downloading:</p><a class="link" href="http://download.easeus.com/free/tb_free.exe">http://download.easeus.com/free/tb_free.exe</a><p class="buy_title">Ready to buy?</p><p class="buy_dis">Save this 40% off coupon for full version upgrade<br />Coupon Code: [ <font>UPGD-4WLG</font> ]</p><a class="button_buy" href="http://www.easeus.com/landing/store/backup.html">Buy Now &gt;&gt;</a></div><div class="right" name="tb"><div class="review"><p class="review_title">Awards & Reviews</p><div class="scrolls"><ul id="download_scrolls" class="clearfix"><li><img src="https://images.easeus.com/images/en/review/pic-cnet-5star-110-50.jpg" alt="cnet review"><p>"Like any good backup tool, it will back up your entire system\'s current state, data, settings and what you want it to"</p></li><li><img src="https://images.easeus.com/images/en/review/pcworld-110-55.jpg" alt="pcworld review"><p>"The Best Free Backup Tool in Existence. Back up partitions, restore partitions &amp; individual files with highly useful backup program"</p></li><li><img src="https://images.easeus.com/images/en/review/softpedia-110-55.jpg" width="110" height="55" alt="softpedia review"><p>"You get an easy to use solution that covers the needs of most users. It can create bootable copies of the system drive"</p></li><li><img src="https://images.easeus.com/images/en/review/pic-10tips2-110-50.jpg" alt="toptenreview"><p>"EaseUS Todo Backup Server provides a large assortment of advanced features and tools to prevent tragic data loss."</p></li></ul></div><div class="clicks" id="download_clicks"><span value="1"></span><span value="2"></span><span value="3"></span><span value="4"></span></div></div><div class="word"><p class="word_title">Customer Says</p><p>"It\'s fast, reliable and 100% sure, never failed restoring an image. Your software is 100% safe disaster recovery." −− Francis van den Heuvel</p><p>"EaseUS Todo Backup has become my first thoughts now. Favorite part is the disk cloning tool." −− Ray</p></div></div><div class="right hidden" name="goback"><div class="word"><p class="word_title">Customer Says</p><p>"Just try your EaseUS System GoBack to get back to my previous system. It is amazing. Before upgrading to Windows 10, I backed up the whole system. It just costs me several minutes to go back to my Windows 8.1." −− Tommy</p><p>"EaseUS System GoBack is an innovative tool to eliminate the anxiety of Windows 10 upgrade. It\'s very useful for me to roll back to my previous Windows 7 when I feel unadaptable with the New Windows 10." −− Anna</p><p>"Thank you guys so much to develop such powerful system recovery software. With strong backup and restoring features, I get my old system and information back easily." −− Micheal</p></div></div><div class="right hidden" name="epm"><div class="review"><p class="review_title">Awards &amp; Reviews</p><div class="scrolls"><ul id="download_scrolls_epm" class="clearfix"><li><img src="https://images.easeus.com/images/en/review/pic-cnet-5star-110-50.jpg" alt="cnet review"><p>"It is a full-featured disk partition manager, which can not only format and partition drives but repartition them."</p></li><li><img src="https://images.easeus.com/images/en/review/pcworld-110-55.jpg" alt="pcworld review"><p>"Perfect partitioning program - one that\'s easy, reliable, versatile, non-destructive - resize a partition without erasing it."</p></li><li><img src="https://images.easeus.com/images/en/review/pic-softonic-110-50.jpg" alt="softonic" width="110"><p>"Managing partitions has never been my cup of tea. I always get the impression that it\'s something difficult - and I\'m sure I\'m not the only one who thinks like that."</p></li><li><img src="https://images.easeus.com/images/en/review/softpedia-110-55.jpg" width="110" height="55" alt="softpedia review"><p>"EaseUS Partition Master is comprehensive, which enables you to perform basic and advanced partition operations."</p></li></ul></div><div class="clicks" id="download_clicks_epm"><span value="1" class=""></span><span value="2" class="current"></span><span value="3"></span><span value="4"></span></div></div><div class="word"><p class="word_title">Customer Says</p><p>"Thank You!!! I downloaded  free version of EaseUS and it worked on my old xp program. It was so user friendly and I really appreciate your expertise." −− J.Balgal</p><p>"Just to leave a word about Easeus on our production environnement. I resized two big partitions on the same server and your product did the trick successfully in about 2 hours." −− Dennis M Hogan</p></div></div></div><span class="landing"></span></div></div>';
				download_html+='<div class="download_pop_2 hidden"><div class="bg"></div><div class="content"><span class="close"></span><p class="title">Download EaseUS Todo Backup Free</p><div class="clearfix"><div class="check_bt clearfix"><p class="check_bt_title">Special price only for a limited time!</p><ul class="tb_new clearfix"><li class="list_1"><span class="best"></span><p><b>Todo Backup Home</b><br>Free lifetime Upgrade License<span class="price"><font class="orange">$35.40</font> <del>$59.00</del></span></p><a href="https://www.cleverbridge.com/505/?scope=checkout&amp;cart=184298&amp;coupon=UPGD-4WLG&amp;x-source=emailetbf&amp;currency=USD">Buy Now</a><p class="dis">One-time fee<br />and enjoy all upgrade FOR FREE.</p></li><li class="list_2"><p><b>Todo Backup Home</b><br>Standard License<span class="price"><font class="orange">$17.40</font> <del>$29.00</del></span></p><a href="https://www.cleverbridge.com/505/?scope=checkout&amp;cart=113174&amp;coupon=UPGD-4WLG&amp;x-source=emailetbf&amp;currency=USD">Buy Now</a><p class="dis">Lifetime license<br />but need to pay every major upgrade.</p></li></ul></div><p class="last_word align_left">* EaseUS are offering registered customers a discount of up to 40% (20%-40%) on SELECTED PRODUCTS, use code <b class="orange">[ UPGD-4WLG ]</b> and <a href="http://www.easeus.com/landing/store/backup.html">Get it now &gt;&gt;</a></p></div></div></div>';
				$('body').append(download_html);
				var thisname='';
				var error=$('.download_pop .error');
				$('#download_email').blur(function(){
					check_mail($(this).val(),error);
				});
				$('.download_pop .checked').click(function(){
					if($(this).hasClass('current')){
						$(this).removeClass('current');
					}else{
						$(this).addClass('current');
					}
				});
				$('.download_pop .close,.download_pop .bg').click(function(){
					$('.download_pop').fadeOut(300);
				});
				$('.download_pop_2 .close,.download_pop_2 .bg').click(function(){
					$('.download_pop_2').fadeOut(300);
				});
				//mail
				var no=1;//fadein scrolls go
				var no_epm=1;//
				$(document).on('click','.download_pop_show',function(){
					//get -> tb name
					thisname=$(this).attr('name');
					//globle
					$('.download_pop .link').removeAttr('onclick');
					$('.download_pop .button_buy').show();
					//end
					$('#ptype').val(thisname);
					if(thisname=='tbfree'){
						var down_link=$(this).attr('href');
						$('.download_pop .title').html('Download EaseUS Todo Backup Free');
						$('#download_poptitle').html('Fill out the form below for a <font>free version</font>.');
						$('.download_pop_2 .title').html('<span class="down">&nbsp;</span><a class="underline" href='+down_link+'>Download EaseUS Todo Backup Free</a>');
						$('.download_pop_2 .tb_new').html('<li class="list_1"><span class="best"></span><p><b>Todo Backup Home</b><br>Free lifetime Upgrade License<span class="price"><font class="orange">$35.40</font> <del>$59.00</del></span></p><a href="https://order.easeus.com/505/purl-store?cart=184298&coupon=UPGD-4WLG&x-source=emailetbf&currency=USD">Buy Now</a><p class="dis">One-time fee<br>and enjoy all upgrade FOR FREE.</p></li><li class="list_2"><p><b>Todo Backup Home</b><br>Standard License<span class="price"><font class="orange">$17.40</font> <del>$29.00</del></span></p><a href="https://order.easeus.com/505/purl-store?cart=113174&coupon=UPGD-4WLG&x-source=emailetbf&currency=USD">Buy Now</a><p class="dis">Lifetime license<br>but need to pay every major upgrade.</p></li>');
					}else if(thisname=='tbhome'){
						$('.download_pop .title').html('Download EaseUS Todo Backup Home');
						$('#download_poptitle').html('Fill out the form below for a <font>30-day free trial</font>.');
						$('.download_pop_2 .title').html('<span class="down">&nbsp;</span><a class="underline" href="http://download.easeus.com/trial/tbh_trial.exe">Download EaseUS Todo Backup Home Trial</a>');
						$('.download_pop_2 .tb_new').html('<li class="list_1"><span class="best"></span><p><b>Todo Backup Home</b><br>Free lifetime Upgrade License<span class="price"><font class="orange">$35.40</font> <del>$59.00</del></span></p><a href="https://order.easeus.com/505/purl-store?cart=184298&coupon=UPGD-4WLG&x-source=emailetbh&currency=USD">Buy Now</a><p class="dis">One-time fee<br>and enjoy all upgrade FOR FREE.</p></li><li class="list_2"><p><b>Todo Backup Home</b><br>Standard License<span class="price"><font class="orange">$17.40</font> <del>$29.00</del></span></p><a href="https://order.easeus.com/505/purl-store?cart=113174&coupon=UPGD-4WLG&x-source=emailetbh&currency=USD">Buy Now</a><p class="dis">Lifetime license<br>but need to pay every major upgrade.</p></li>');
					}else if(thisname=='tbwork'){
						$('.download_pop .title').html('Download EaseUS Todo Backup Workstation');
						$('#download_poptitle').html('Fill out the form below for a <font>30-day free trial</font>.');
						$('.download_pop_2 .title').html('<span class="down">&nbsp;</span><a class="underline" href="http://download.easeus.com/trial/tb_enterprise_trial.exe">Download EaseUS Todo Backup Workstation Trial</a>');
						$('.download_pop_2 .tb_new').html('<li class="list_1"><span class="best"></span><p><b>Todo Backup Workstation</b><br>Free lifetime Upgrade License<span class="price"><font class="orange">$55.30</font> <del>$79.00</del></span></p><a href="https://order.easeus.com/505/purl-store?cart=184299&coupon=UPGD-4WLG&x-source=emailetbw&currency=USD">Buy Now</a><p class="dis">One-time fee<br>and enjoy all upgrade FOR FREE.</p></li><li class="list_2"><p><b>Todo Backup Workstation</b><br>Standard License<span class="price"><font class="orange">$23.40</font> <del>$39.00</del></span></p><a href="https://order.easeus.com/505/purl-store?cart=113175&coupon=UPGD-4WLG&x-source=emailetbw&currency=USD">Buy Now</a><p class="dis">Lifetime license<br>but need to pay every major upgrade.</p></li>');
					}else if(thisname=='tbserver'){
						$('.download_pop .title').html('Download EaseUS Todo Backup Server');
						$('#download_poptitle').html('Fill out the form below for a <font>30-day free trial</font>.');
						$('.download_pop_2 .title').html('<span class="down">&nbsp;</span><a class="underline" href="http://download.easeus.com/trial/tb_enterprise_trial.exe">Download EaseUS Todo Backup Server Trial</a>');
						$('.download_pop_2 .tb_new').html('<li class="list_1"><span class="best"></span><p><b>Todo Backup Server</b><br>Free lifetime Upgrade License<span class="price"><font class="orange">$251.30</font> <del>$359.00</del></span></p><a href="https://order.easeus.com/505/purl-store?cart=184300&coupon=UPGD-4WLG&x-source=emailetbs&currency=USD">Buy Now</a><p class="dis">One-time fee<br>and enjoy all upgrade FOR FREE.</p></li><li class="list_2"><p><b>Todo Backup Server</b><br>Standard License<span class="price"><font class="orange">$119.40</font> <del>$199.00</del></span></p><a href="https://order.easeus.com/505/purl-store?cart=113176&coupon=UPGD-4WLG&x-source=emailetbs&currency=USD">Buy Now</a><p class="dis">Lifetime license<br>but need to pay every major upgrade.</p></li>');
					}else if(thisname=='tbaserver'){
						$('.download_pop .title').html('Download EaseUS Todo Backup Advanced Server');
						$('#download_poptitle').html('Fill out the form below for a <font>30-day free trial</font>.');
						$('.download_pop_2 .title').html('<span class="down">&nbsp;</span><a class="underline" href="http://download.easeus.com/trial/tb_enterprise_trial.exe">Download EaseUS Todo Backup Advanced Server Trial</a>');
						$('.download_pop_2 .tb_new').html('<li class="list_1"><span class="best"></span><p><b>Todo Backup Advanced Server</b><br>Free lifetime Upgrade License<span class="price"><font class="orange">$321.30</font> <del>$459.00</del></span></p><a href="https://order.easeus.com/505/purl-store?cart=184301&coupon=UPGD-4WLG&x-source=emailetbas&currency=USD">Buy Now</a><p class="dis">One-time fee<br>and enjoy all upgrade FOR FREE.</p></li><li class="list_2"><p><b>Todo Backup Advanced Server</b><br>Standard License<span class="price"><font class="orange">$179.40</font> <del>$299.00</del></span></p><a href="https://order.easeus.com/505/purl-store?cart=113177&coupon=UPGD-4WLG&x-source=emailetbas&currency=USD">Buy Now</a><p class="dis">Lifetime license<br>but need to pay every major upgrade.</p></li>');
					}else if(thisname=='tbt'){
						$('.download_pop .title').html('Download EaseUS Todo Backup Technician');
						$('.download_pop .link').replaceWith('<a class="link" href="http://download.easeus.com/trial/tb_enterprise_trial.exe">http://download.easeus.com/trial/tb_enterprise_trial.exe</a>');
						$('#download_poptitle').html('Fill out the form below for a <font>30-day free trial</font>.');
						$('.download_pop .buy_dis').html('EaseUS are offering registered customers a discount of up to 40% (20%-40%) on SELECTED PRODUCTS, use code <font>[ UPGD-4WLG ]</font> and <a href="http://www.easeus.com/landing/store/backup.html">Get it now &gt;&gt;</a>');
						$('.download_pop .button_buy').hide();
					}else if(thisname=='tbcmc'){
						$('.download_pop .title').html('Download EaseUS Backup Center');
						$('.download_pop .link').replaceWith('<a class="link" href="http://download.easeus.com/trial/ebc_trial.exe">http://download.easeus.com/trial/ebc_trial.exe</a>');
						$('#download_poptitle').html('Fill out the form below for free trial.');
						$('.download_pop .buy_dis').html('EaseUS are offering registered customers a discount of up to 40% (20%-40%) on SELECTED PRODUCTS, use code <font>[ UPGD-4WLG ]</font> and <a href="http://www.easeus.com/landing/store/backup.html">Get it now &gt;&gt;</a>');
						$('.download_pop .button_buy').hide();
					}else if(thisname=='edm'){
						$('.download_pop .title').html('Download EaseUS Deploy Manager');
						$('.download_pop .link').replaceWith('<div class="link">For Workstation: <br /><a href="http://download.easeus.com/trial/edm_trial.exe">http://download.easeus.com/trial/edm_trial.exe</a><br />For Server: <br /><a href="http://download.easeus.com/trial/edms_trial.exe">http://download.easeus.com/trial/edms_trial.exe</a></div>');
						$('#download_poptitle').html('Fill out the form below for free trial.');
						$('.download_pop .buy_dis').html('EaseUS are offering registered customers a discount of up to 40% (20%-40%) on SELECTED PRODUCTS, use code <font>[ UPGD-4WLG ]</font> and <a href="http://www.easeus.com/landing/store/backup.html">Get it now &gt;&gt;</a>');
						$('.download_pop .button_buy').hide();
					}else if(thisname=='dch'){
						$('.download_pop .title').html('Download EaseUS Disk Copy Home');
						$('.download_pop .link').replaceWith('<a class="link" href="http://download.easeus.com/free/EaseUS_DiskCopy_Home.exe">http://download.easeus.com/free/EaseUS_DiskCopy_Home.exe</a>');
						$('#download_poptitle').html('Fill out the form below for <font>Disk Copy Home</font>.');
						$('.download_pop .buy_dis').html('<a href="https://order.easeus.com/505/purl-store?cart=172930&coupon=UPGD-4WLG&x-source=emailetbdc&currency=USD">Get the full version of Disk Copy Technician now $59.40</a><br />Or Use 40% Off Coupon Code Later [ <font>UPGD-4WLG</font> ]');
					}else if(thisname=='goback'){
						$('.download_pop .title').html('Download EaseUS System GoBack Free');
						$('.download_pop .link').replaceWith('<a class="link" href="http://download.easeus.com/free/goback.exe">http://download.easeus.com/free/goback.exe</a>');
						$('#download_poptitle').html('Fill out the form below for a <font>free version</font>.');
						$('.download_pop .buy_dis').html('Save this 40% off coupon for full version upgrade<br />Coupon Code: [ <font>UPGD-4WLG</font> ]');
					}//now epm begin
					else if(thisname=='epmfree'){
						var down_link=$(this).attr('href');
						$('.download_pop .title').html('Download EaseUS Partition Master Free');						
						$('#download_poptitle').html('Fill out the form below for a <font>free version</font>.');
						$('.download_pop_2 .title').html('<span class="down">&nbsp;</span><a class="underline" href="'+down_link+'">Download EaseUS Partition Master Free</a>');
						$('.download_pop_2 .tb_new').html('<li class="list_1"><span class="best"></span><p><b>Partition Master Professional</b><br>Free lifetime Upgrade License<span class="price"><font class="orange">$41.96</font> <del>$59.95</del></span></p><a href="https://order.easeus.com/505/purl-store?cart=138708&coupon=UPGD-4WLG&x-source=emailepme&currency=USD">Buy Now</a><p class="dis">One-time fee<br>and enjoy all upgrade FOR FREE.</p></li><li class="list_2"><p><b>Partition Master Professional</b><br>Standard License<span class="price"><font class="orange">$23.97</font> <del>$39.95</del></span></p><a href="https://order.easeus.com/505/purl-store?cart=106499&coupon=UPGD-4WLG&x-source=emailepme&currency=USD">Buy Now</a><p class="dis">Lifetime license<br>but need to pay every major upgrade.</p></li>');
					}else{
						return true;
					}
					//
					$('.download_pop').fadeIn(300);
					$('.download_pop .no2').hide();
					$('.download_pop .no1').show();
					//
					$('.download_pop .right').addClass('hidden');
					if(thisname=='goback'){
						$('.download_pop .right[name="goback"]').removeClass('hidden');
					}else if(thisname=='epmfree'){
						$('.download_pop .right[name="epm"]').removeClass('hidden');
						//fadein scrolls go once
						if(no_epm==1){
							no_epm=2;
							//scroll all
							var scrolls=new globle_scroll('#download_scrolls_epm','','','#download_clicks_epm');
							scrolls.gos();
						}
					}else{
						$('.download_pop .right[name="tb"]').removeClass('hidden');
						//fadein scrolls go once
						if(no==1){
							no=2;
							//scroll all
							var scrolls=new globle_scroll('#download_scrolls','','','#download_clicks');
							scrolls.gos();
						}
					}
					return false;
				});
				$('.download_pop .submit').click(function(){
					if(submit_s=='no'){
						return false;
					}else{
						$('.download_pop .landing').show();
						var email_val=$('#download_email').val();
						var ptype_val=$('#ptype').val();
						var web_val=$('#web').val();
						var dom=document.createElement('script');
						dom.src='https://www.easeus.com/mail/download/?email='+email_val+'&ptype='+ptype_val+'&web='+web_val+'&callback=download_fun';	
						document.getElementsByTagName('head')[0].appendChild(dom);
					}
				});
				download_fun=function(val){
					$('.download_pop .landing').hide();
					var val = JSON.parse(val);
					val=val.info;
					if(val==1){
						if(thisname=='tbfree' || thisname=='tbhome' || thisname=='tbwork' || thisname=='tbserver' || thisname=='tbaserver' || thisname=='epmfree'){
							$('.download_pop').fadeOut(300);
							$('.download_pop_2').fadeIn(300);
						}else{
							$('.download_pop .no1').hide(200);
							$('.download_pop .no2').show(200);
						}
					}else if(val==0){
						error.removeClass('hidden').html('E-mail can\'t be empty');
					}else{
						error.removeClass('hidden').html('Please enter a valid e-mail');
					}
				};
			};
			this.wap_email=function(){
				var download_html='<div class="download_wap_pop"><span class="close"></span><span class="loading"></span><p class="title" id="download_wap_pop_title">EaseUS Data Recovery Wizard</p><p class="des">The program you want to try is for desktops. We will email the trial link to you right now.</p><div class="mail_box"><input id="download_email" class="text" type="text" placeholder="Your email address"/><input type="hidden" name="ptype" id="ptype" /><input type="hidden" name="web" id="web" value="easeus"><input class="submit" type="submit" value="Submit" /></div><p class="error hidden">&nbsp;</p><div class="success hidden"><p class="title">Submit Successfully!</p><p class="des">The trial link will be sent to you right now, please check your mailbox later. If the email cannot reach you, please check your email address availability. Thanks!</p></div><div class="this_scroll hidden" ><ul class="list clearfix"><li><div class="logo"><img src="/images_2016/drw_win/awards-4.png" width="320" height="70"></div><span class="quote_f">&nbsp;</span><div class="word">EaseUS Data Recovery Wizard can recover data from your hard drive, USB drives, memory cards, and other storage devices.</div><span class="quote_b">&nbsp;</span></li><li><div class="logo"><img src="/images_2016/drw_win/awards-pc-world.png" width="320" height="70"></div><span class="quote_f">&nbsp;</span><div class="word">Perfect EaseUS partitioning program - one that\'s easy, reliable, versatile, non-destructive - resize a partition without erasing it.</div><span class="quote_b">&nbsp;</span></li><li><div class="logo"><img src="/images_2016/drw_win/awards-2.png" width="320" height="70"></div><span class="quote_f">&nbsp;</span><div class="word">EaseUS Todo Backup software is pretty great for backup software, but it works well and contains all the features you need.</div><span class="quote_b">&nbsp;</span></li><li><div class="logo"><img src="/images_2016/drw_win/awards-1.png" width="320" height="70"></div><span class="quote_f">&nbsp;</span><div class="word">EaseUS software programs are efficient and user-friendly utilities that can successfully assist users to make digital life easy.</div><span class="quote_b">&nbsp;</span></li></ul><div class="ol"><span class="current" value="1"></span><span value="2"></span><span value="3"></span><span value="4"></span></div></div><div class="this_android hidden"><p class="title">Android Data Recovery App</p><p class="des">EaseUS MobiSaver for Android app is the easiest and fastest widget to recover your deleted files on the tips of your fingers.</p><a class="bt" href="https://play.google.com/store/apps/details?id=com.easeus.mobisaver" onclick="ga(\'send\', \'event\', \'msa_app_trial\', \'msa_app_trial\', \'pop_up_download\');"></a></div></div>';
				$('body').append(download_html);
				var thisname='';
				var error=$('.download_wap_pop .error');
				$('.download_wap_pop .text').blur(function(){
					check_mail($(this).val(),error);
				});
				$('.download_wap_pop .close').click(function(){
					$('.download_wap_pop').fadeOut(300);
					$('body,html').removeClass('wap_pop');
				});
				var no=1;//fadein scrolls go
				$(document).on('click','.download_pop_show',function(){
					//get -> tb name
					thisname=$(this).attr('name');
					$('#ptype').val(thisname);
					if(thisname=='drwf'){
						var down_link=$(this).attr('href');
						$('#download_wap_pop_title').html('EaseUS Data Recovery Wizard Free');
					}else if(thisname=='drwp'){
						$('#download_wap_pop_title').html('EaseUS Data Recovery Wizard Professional');
					}else if(thisname=='drwt'){
						$('#download_wap_pop_title').html('EaseUS Data Recovery Wizard Technician');
					}else if(thisname=='drwmf'){
						$('#download_wap_pop_title').html('EaseUS Data Recovery Wizard for Mac Free ');
					}else if(thisname=='drwm'){
						$('#download_wap_pop_title').html('EaseUS Data Recovery Wizard for Mac');
					}else if(thisname=='drwmt'){
						$('#download_wap_pop_title').html('EaseUS Data Recovery Wizard for Mac Technician');
					}else if(thisname=='erw'){
						$('#download_wap_pop_title').html('EaseUS Email Recovery Wizard');
					}else if(thisname=='mobif'){
						$('#download_wap_pop_title').html('EaseUS MobiSaver Free');
					}else if(thisname=='mobi'){
						$('#download_wap_pop_title').html('EaseUS MobiSaver');
					}else if(thisname=='mobifm'){
						$('#download_wap_pop_title').html('EaseUS MobiSaver Free for Mac');
					}else if(thisname=='mobim'){
						$('#download_wap_pop_title').html('EaseUS MobiSaver for Mac');
					}else if(thisname=='mobiaf'){
						$('#download_wap_pop_title').html('EaseUS MobiSaver for Android Free');
					}else if(thisname=='mobia'){
						$('#download_wap_pop_title').html('EaseUS MobiSaver for Android');
					}else if(thisname=='epmfree'){
						$('#download_wap_pop_title').html('EaseUS Partition Master Free');
					}else if(thisname=='epmp'){
						$('#download_wap_pop_title').html('EaseUS Partition Master Professional');
					}else if(thisname=='epms'){
						$('#download_wap_pop_title').html('EaseUS Partition Master Server');
					}else if(thisname=='epmu'){
						$('#download_wap_pop_title').html('EaseUS Partition Master Unlimited');
					}else if(thisname=='epmt'){
						$('#download_wap_pop_title').html('EaseUS Partition Master Technician');
					}else if(thisname=='tbfree'){
						$('#download_wap_pop_title').html('EaseUS Todo Backup Free');
					}else if(thisname=='tbhome'){
						$('#download_wap_pop_title').html('EaseUS Todo Backup Home');
					}else if(thisname=='tbwork'){
						$('#download_wap_pop_title').html('EaseUS Todo Backup Workstation');
					}else if(thisname=='tbserver'){
						$('#download_wap_pop_title').html('EaseUS Todo Backup Server');
					}else if(thisname=='tbaserver'){
						$('#download_wap_pop_title').html('EaseUS Todo Backup Advanced Server');
					}else if(thisname=='tbt'){
						$('#download_wap_pop_title').html('EaseUS Todo Backup Technician');
					}else if(thisname=='tbm'){
						$('#download_wap_pop_title').html('EaseUS Todo Backup for Mac');
					}else if(thisname=='tbcmc'){
						$('#download_wap_pop_title').html('EaseUS Backup Center');
					}else if(thisname=='edm'){
						$('#download_wap_pop_title').html('EaseUS Deploy Manager');
					}else if(thisname=='pctf'){
						$('#download_wap_pop_title').html('EaseUS Todo PCTrans Free');
					}else if(thisname=='pctp'){
						$('#download_wap_pop_title').html('EaseUS Todo PCTrans Professional');
					}else if(thisname=='pctt'){
						$('#download_wap_pop_title').html('EaseUS Todo PCTrans Technician');
					}else if(thisname=='es'){
						$('#download_wap_pop_title').html('EaseUS EverySync');
					}else if(thisname=='cgm'){
						$('#download_wap_pop_title').html('EaseUS CleanGenius for Mac');
					}else if(thisname=='goback'){
						$('#download_wap_pop_title').html('EaseUS System GoBack Free');
					}else if(thisname=='mmfree'){
						$('#download_wap_pop_title').html('EaseUS MobiMover Free');
					}else if(thisname=='mmtrial'){
						$('#download_wap_pop_title').html('EaseUS MobiMover');
					}else{
						return true;
					}
					//
					$('.download_wap_pop').fadeIn(400);
					$('body,html').addClass('wap_pop');
					//
					if(thisname=='mobiaf' || thisname=='mobia'){
						$('.download_wap_pop .this_scroll').addClass('hidden');
						$('.download_wap_pop .this_android').removeClass('hidden');
						var u = navigator.userAgent;
						var isAndroid = u.indexOf('Android') > -1 || u.indexOf('Adr') > -1;
						if(isAndroid){
							$('.download_wap_pop .this_android .bt').attr({href:'market://details?id=com.easeus.mobisaver'});
						}
					}else{
						$('.download_wap_pop .this_scroll').removeClass('hidden');
						$('.download_wap_pop .this_android').addClass('hidden');
						if(no==1){
							var scrolls=new globle_scroll('.download_wap_pop .list','','','.download_wap_pop .ol');
							scrolls.gos();
							no=2;
						}
					}
					return false;
				});
				//submit
				$('.download_wap_pop .submit').click(function(){
					if(submit_s=='no'){
						return false;
					}else{
						$('.download_wap_pop .loading').show();
						var email_val=$('#download_email').val();
						var ptype_val=$('#ptype').val();
						var web_val=$('#web').val();
						var dom=document.createElement('script');
						dom.src='https://www.easeus.com/mail.php?email='+email_val+'&ptype='+ptype_val+'&web='+web_val+'&callback=download_fun';	
						document.getElementsByTagName('head')[0].appendChild(dom);
					}
				});
				download_fun=function(val){
					$('.download_wap_pop .loading').hide();
					if(val==1){
						$('.download_wap_pop .mail_box').addClass('hidden');
						$('.download_wap_pop .success').removeClass('hidden');
					}else if(val==0){
						error.removeClass('hidden').html('E-mail can\'t be empty');
					}else{
						error.removeClass('hidden').html('Please enter a valid e-mail');
					}
				};
			}
		};
		var download_checks=new download_check();
		if(globle_variable.ispc){//is pc or wap
			download_checks.email();
		}else{
			download_checks.wap_email();
		}
	};
	download_mail();
	$('.download_pop .word_hide_show').each(function(){
		var word_hide_show=$(this);
		var word=word_hide_show.val();
		word_hide_show.focus(function(){
			var this_word=$(this).val();
			if(word==this_word){
				word_hide_show.val('');
			}
		}).blur(function(){
			var this_word=$(this).val();
			if(this_word==''){
				word_hide_show.val(word);
			}
		});
	});
});